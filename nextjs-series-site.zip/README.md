# موقع عرض المسلسلات

مشروع Next.js + Tailwind CSS لعرض المسلسلات.